# Bio - IA — versión pública

Aplicación web de química con frontend + backend + API de IA.

## 1. Requisitos
- Node.js 18+
- Una clave de API de un proveedor de IA compatible con el SDK de OpenAI.
- Cuenta de hosting para publicar el servidor.

## 2. Ejecutar localmente

```bash
npm install
cp .env.example .env
```

Edita `.env` y coloca tu clave:

```env
OPENAI_API_KEY=tu_clave
OPENAI_MODEL=gpt-5-mini
PORT=3000
```

Después:

```bash
npm start
```

Abre `http://localhost:3000`.

## 3. Publicar

Puedes subir este proyecto a un hosting que ejecute Node.js. Por ejemplo, Vercel puede desplegar aplicaciones Node y permite configurar secretos mediante Environment Variables.

Configura en el hosting:
- `OPENAI_API_KEY`
- `OPENAI_MODEL` (opcional)
- `PORT` (normalmente lo administra el hosting)

NO subas `.env` a GitHub.

## 4. Seguridad básica incluida
- La clave de API solo se usa en el servidor.
- El navegador llama a `/api/chat`, nunca directamente a la API con la clave.
- El backend limita el historial enviado y el tamaño de cada mensaje.
- Errores de la API no exponen la clave.

## 5. Antes de abrirlo al público
Para una página pública con muchos usuarios conviene añadir autenticación, rate limiting, moderación, límites de gasto y registro de errores. Así evitas que una persona consuma todo el presupuesto de la API.
