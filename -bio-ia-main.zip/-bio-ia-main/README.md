# -bio-ia
Utilízalos para quimica
